#!/bin/bash
./run.sh -r "python script/bagdump.py" "$@"