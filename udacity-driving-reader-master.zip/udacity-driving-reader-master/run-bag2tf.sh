#!/bin/bash
./run.sh -r "python script/bag2tf.py" "$@"
